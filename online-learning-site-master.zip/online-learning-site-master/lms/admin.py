from django.contrib import admin
from lms.models import UserProfileInfo,Instructor,courseforms
# Register your models here.
admin.site.register(UserProfileInfo)
admin.site.register(Instructor)
admin.site.register(courseforms)
#username=yukta
#password=yukta12345
